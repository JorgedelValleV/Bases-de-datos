def v_confirmar='n';
--variable v_confirmar char(20);
--exec :v_confirmar:='n';
