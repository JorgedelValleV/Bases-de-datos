prompt '�Confirmar la reserva?';
accept v_confirmar;
